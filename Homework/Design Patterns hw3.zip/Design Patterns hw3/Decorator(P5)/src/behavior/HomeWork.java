package behavior;

/**
 *
 * @author Fefe-Hern <https://github.com/Fefe-Hern>
 */
public interface HomeWork {
    public void doHomework();
}
