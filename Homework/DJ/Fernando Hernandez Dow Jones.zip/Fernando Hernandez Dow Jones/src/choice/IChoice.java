package choice;

/**
 *
 * @author Fefe-Hern <https://github.com/Fefe-Hern>
 */
public interface IChoice {
    public int myChoice();
}
