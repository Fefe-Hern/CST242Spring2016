package prob2;

/**
 *
 * @author Fefe-Hern <https://github.com/Fefe-Hern>
 */
interface BookMarkup {
    void markUp();
}
