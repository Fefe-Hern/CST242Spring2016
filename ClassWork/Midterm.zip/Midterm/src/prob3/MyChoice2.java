package prob3;

/**
 *
 * @author Fefe-Hern <https://github.com/Fefe-Hern>
 */
public class MyChoice2 implements IChoice {

    @Override
    public double myChoice(double price) {
        return price * 0.9;
    }
    
}
